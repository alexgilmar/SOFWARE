<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservas - Turismo Puno</title>
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/estilos.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="contenedor reservas">
        <h1 class="titulo-reservas">Reservas</h1>
        <section class="contenido-reservas">
            <p>
                ¡Planifica tu viaje a Puno y realiza tus reservas con nosotros! Completa el formulario a continuación para reservar hoteles, restaurantes y actividades turísticas.
            </p>
            <form action="procesar_reserva.php" method="post" class="formulario-reserva">
                <div class="input-formulario">
                    <label for="nombre">Nombre</label>
                    <input type="text" name="nombre" id="nombre" required>
                </div>
                <div class="input-formulario">
                    <label for="apellido">Apellido</label>
                    <input type="text" name="apellido" id="apellido" required>
                </div>
                <div class="input-formulario">
                    <label for="correo">Correo</label>
                    <input type="email" name="correo" id="correo" required>
                </div>
                <div class="input-formulario">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" name="telefono" id="telefono" required>
                </div>
                <div class="input-formulario">
                    <label for="fecha">Fecha de Reserva</label>
                    <input type="date" name="fecha" id="fecha" required>
                </div>
                <div class="input-formulario">
                    <label for="tipo_reserva">Tipo de Reserva</label>
                    <select name="tipo_reserva" id="tipo_reserva" required>
                        <option value="hotel">Hotel</option>
                        <option value="restaurante">Restaurante</option>
                        <option value="actividad">Actividad Turística</option>
                    </select>
                </div>
                <div class="input-formulario">
                    <label for="mensaje">Mensaje</label>
                    <textarea name="mensaje" id="mensaje" rows="5"></textarea>
                </div>
                <div class="input-formulario">
                    <label for="metodo_pago">Método de Pago</label>
                    <select name="metodo_pago" id="metodo_pago" required>
                        <option value="tarjeta_credito">Tarjeta de Crédito</option>
                        <option value="paypal">PayPal</option>
                        <option value="transferencia_bancaria">Transferencia Bancaria</option>
                    </select>
                </div>
                <div class="btn-formulario">
                    <input type="submit" class="btn btn-verde" value="Enviar">
                </div>
            </form>
        </section>
    </div>

    <?php include('footer.php'); ?>
    
    <script src="../js/app.js"></script>
</body>

</html>
