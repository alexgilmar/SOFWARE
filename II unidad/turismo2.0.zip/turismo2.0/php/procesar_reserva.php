<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = htmlspecialchars($_POST['nombre']);
    $apellido = htmlspecialchars($_POST['apellido']);
    $correo = htmlspecialchars($_POST['correo']);
    $telefono = htmlspecialchars($_POST['telefono']);
    $fecha = htmlspecialchars($_POST['fecha']);
    $tipo_reserva = htmlspecialchars($_POST['tipo_reserva']);
    $mensaje = htmlspecialchars($_POST['mensaje']);
    $metodo_pago = htmlspecialchars($_POST['metodo_pago']);

    // Conexión a la base de datos
    $conn = new mysqli('localhost', 'root', '', 'turismo_puno');

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "INSERT INTO reservas (nombre, apellido, correo, telefono, fecha, tipo_reserva, mensaje, metodo_pago)
            VALUES ('$nombre', '$apellido', '$correo', '$telefono', '$fecha', '$tipo_reserva', '$mensaje', '$metodo_pago')";

    if ($conn->query($sql) === TRUE) {
        echo "Reserva realizada con éxito";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva Procesada</title>
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <?php include('header.php'); ?>

    <div class="contenedor">
        <h1>Reserva Procesada</h1>
        <p>Gracias por realizar su reserva. Nos pondremos en contacto con usted pronto.</p>
    </div>

    <?php include('footer.php'); ?>

    <script src="../js/app.js"></script>
</body>
</html>
