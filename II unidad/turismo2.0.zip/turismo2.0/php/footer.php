<footer class="footer">
    <p>Todos los derechos reservados &copy; 2024 Turismo Puno, desarrollado por AlexGSR</p>
</footer>
