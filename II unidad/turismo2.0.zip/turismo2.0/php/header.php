<header class="encabezado">
    <div class="contenedor-navegacion">
        <div class="contenido-navegacion contenedor">
            <div class="logo">
                <h2>PUNO <span class="rojo">HER</span><span>MO</span><span class="rojo">SO</span></h2>
            </div>
            <nav class="navegacion ocultar">
                <a href="../index.php">Inicio</a>
                <a href="biografia.php">Biografía</a>
                <a href="../comidas.php">Comidas Típicas</a>
                <a href="reservas.php">Reservas</a>
                <a href="#">Contacto</a>
                <a href="cerrar_sesion.php">Cerrar sesión</a>
            </nav>
            <div class="hamburguesa">
                <span></span><span></span><span></span>
            </div>
        </div>
    </div>
</header>
