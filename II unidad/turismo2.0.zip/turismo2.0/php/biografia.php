<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biografía de Puno y sus Comidas</title>
    <link rel="stylesheet" href="../css/normalize.css">
    <link rel="stylesheet" href="../css/estilos.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="contenedor biografia">
        <h1 class="titulo-biografia">Biografía de Puno y sus Comidas</h1>
        <section class="contenido-biografia">
            <p>
                Puno, conocida como la "Capital Folklórica del Perú", es una ciudad situada a orillas del Lago Titicaca,
                el lago navegable más alto del mundo. Con una rica historia y cultura, Puno es un destino turístico
                imprescindible para aquellos que desean experimentar las tradiciones y costumbres andinas en su máximo
                esplendor.
            </p>
            <p>
                La gastronomía de Puno es tan variada y rica como su cultura. Entre los platos más emblemáticos se
                encuentran:
            </p>
            <ul>
                <li><strong>Chupe de Quinua:</strong> Una deliciosa sopa hecha a base de quinua, papas, verduras y carne
                    de res o pollo. Es un plato nutritivo y reconfortante, perfecto para las frías noches altiplánicas.
                </li>
                <li><strong>Trucha a la Parrilla:</strong> La trucha del Lago Titicaca es famosa por su sabor y
                    frescura. Se prepara a la parrilla y se sirve con papas y ensalada, ofreciendo una experiencia
                    culinaria única.
                </li>
                <li><strong>Pesque de Quinua:</strong> Un plato tradicional a base de quinua cocida, leche y queso. Es
                    cremoso y delicioso, ideal para acompañar cualquier comida.
                </li>
                <li><strong>Asado de Cordero:</strong> Preparado con cordero local, este plato se cocina lentamente
                    hasta que la carne esté tierna y jugosa. Se suele servir con papas y ensaladas.
                </li>
                <li><strong>Ceviche de Trucha:</strong> Una versión andina del clásico ceviche peruano, hecho con trucha
                    fresca del Lago Titicaca, marinada en limón y acompañada de cebolla, ají y cilantro.
                </li>
            </ul>
            <p>
                Estos son solo algunos ejemplos de la rica gastronomía que Puno tiene para ofrecer. Cada plato refleja
                la diversidad y riqueza cultural de esta región única del Perú.
            </p>
        </section>
    </div>

    <?php include('footer.php'); ?>
    
    <script src="../js/app.js"></script>
</body>

</html>
