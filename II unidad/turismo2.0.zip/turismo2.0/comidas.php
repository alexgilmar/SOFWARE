<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comidas Típicas de Puno</title>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    
    <?php include 'php/header.php'; ?>
    <main class="contenedor">
        <h1>Comidas Típicas de Puno</h1>
        <div class="comidas">
            <div class="comida">
                <img src="assets/img/Cancacho-min.png" alt="Cancacho">
                <h2>Cancacho</h2>
                <p>El cancacho es un plato típico de Puno, preparado con cordero o cerdo asado, acompañado de papas y ensaladas.</p>
            </div>
            <div class="comida">
                <img src="assets/img/230-imagen-162629122021.jpg" alt="Chupe de Quinua">
                <h2>Chupe de Quinua</h2>
                <p>Una deliciosa sopa hecha a base de quinua, papas, verduras y carne de res o pollo.</p>
            </div>
            <div class="comida">
                <img src="assets/img/images.jpeg" alt="Platos Típicos">
                <h2>Platos Típicos</h2>
                <p>Una variedad de platos tradicionales que muestran la riqueza culinaria de Puno.</p>
            </div>
            <div class="comida">
                <img src="assets/img/Pachamanca-1.jpg" alt="Pachamanca">
                <h2>Pachamanca</h2>
                <p>Un plato andino preparado en un horno de tierra, con carnes, papas, maíz y otros ingredientes.</p>
            </div>
            <div class="comida">
                <img src="assets/img/punojpg.webp" alt="Trucha a la Parrilla">
                <h2>Trucha a la Parrilla</h2>
                <p>La trucha del Lago Titicaca es famosa por su sabor y frescura, se prepara a la parrilla y se sirve con papas y ensalada.</p>
            </div>
            <div class="comida">
                <img src="assets/img/unnamed.jpg" alt="Ceviche de Trucha">
                <h2>Ceviche de Trucha</h2>
                <p>Una versión andina del clásico ceviche peruano, hecho con trucha fresca del Lago Titicaca, marinada en limón y acompañada de cebolla, ají y cilantro.</p>
            </div>
        </div>
    </main>
    <?php include('php/footer.php'); ?>
</body>
</html>
