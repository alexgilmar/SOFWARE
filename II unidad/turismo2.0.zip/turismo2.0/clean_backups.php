<?php
$dir = __DIR__ . '/backups';
$days = 7; 

$files = glob($dir . '/*');

foreach ($files as $file) {
    if (is_file($file)) {
        if (time() - filemtime($file) >= $days * 24 * 60 * 60) {
            unlink($file);
        }
    }
}
?>
