<!DOCTYPE html>
<html lang="es">
<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit();
}
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Turismo Puno</title>
    <script src="https://kit.fontawesome.com/283335a286.js" crossorigin="anonymous"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Arima+Madurai:wght@700&family=Mulish:wght@400;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    <header class="encabezado">
        <div class="contenedor-navegacion">
            <div class="contenido-navegacion contenedor">
                <div class="logo">
                    <h2>PUNO <span class="rojo">HER</span><span>MO</span><span class="rojo">SO</span></h2>
                </div>
                    <nav class="navegacion ocultar">
                        <a href="../index.php">Inicio</a>
                        <a href="php/biografia.php">Biografía</a>
                        <a href="comidas.php">Comidas Típicas</a>
                        <a href="php/reservas.php">Reservas</a>
                        <a href="#">Contacto</a>
                        <a href="cerrar_sesion.php">Cerrar sesión</a>
                </nav>
                <div class="hamburguesa">
                    <span></span><span></span><span></span>
                </div>
            </div>
        </div>
        <div class="contenido-header">
            <div class="contenedor-encabezado">
                <div class="texto-encabezado">
                    <h2>Puno ciudad del Inca</h2>
                    <a href="#" class="btn bordes">Guía Útil</a>
                </div>
                <video autoplay loop muted>
                    <source src="assets/videopuno.mp4" type="video/mp4">
                    Tu navegador no soporta la etiqueta de video.
                </video>
            </div>
        </div>
    </header>

    <div class="contenedor-nosotros contenedor">
        <div class="texto-nosotros">
            <p class="bienvenida">Bienvenido a Puno</p>
            <h1>Turismo en Puno</h1>
            <p>Es una plataforma web diseñada para ofrecer una experiencia completa y enriquecedora a los turistas interesados en explorar diversos destinos. La página web no solo permite a los usuarios hacer reservas de hoteles, restaurantes y actividades, sino que también proporciona un espacio para que compartan sus opiniones y experiencias, ayudando a otros viajeros a tomar decisiones informadas.</p>
            <a href="#" class="btn btn-rojo">Contactar</a>
        </div>
        <div class="imagenes-nosotros">
            <div class="imagen1">
                <img data-src="assets/img/nosotros1.webp" alt="mujer comiendo pizza">
            </div>
            <div class="imagenes2">
                <img data-src="assets/img/nosotros2.webp" alt="mujeres comiendo pizza">
                <img data-src="assets/img/nosotros3.webp" alt="plato con pasta">
            </div>
        </div>
    </div>

    

    <div class="separador">
        <div class="contenido-separador contenedor">
            <h2>Comida Puneña para empezar el día</h2>
            <p>Empieza tu día comiendo deliciosa comida o un café Puneño</p>
            <a href="#" class="btn btn-verde">Ordenar ahora</a>
        </div>
    </div>

    <section class="chef contenedor">
        <h2>Chef Puneños</h2>
        <div class="contenido-chef">
            <div class="texto-chef">
                <h3>La excelencia está en la diversidad y el modo de progresar es conocer y comparar las diversidades de productos, culturas y técnicas</h3>
                <p>El Perú ha sido catalogado como uno de los mejores destinos culinarios en los últimos años y la gastronomía de Puno reafirma esa designación. 
                    La cocina puneña se caracteriza por su preparación en horno de leña y ollas de barro, dándonos una conexión más cercana a la madre tierra.
                    
                    Se dice en la leyenda que Manco Cápac y Mama Ocllo aprovecharon los insumos locales que la naturaleza bondadosamente les ofrecía, tales como la quinua, 
                    los tubérculos, el chuño, las hierbas y los granos. Las tradiciones se mantuvieron y fueron el pilar para la gastronomía puneña que hoy conocemos. 
                    Si bien se ha visto influenciada y refinada con diversas técnicas, aún mantiene ese arte culinario propio del altiplano.</p>
                <a href="php/biografia.php" class="btn btn-verde">Leer Biografía</a>
            </div>
            <div class="imagen-chef">
                <img data-src="assets/img/000455740W.jpg" alt="fotografía del chef">
            </div>
        </div>
    </section>

    <div class="formulario-contacto contenedor">
        <div class="informacion-contacto">
            <h3>Contáctanos</h3>
            <p><i class="fas fa-map-marker-alt"></i> JR. matate buscando S/N</p>
            <p><i class="fas fa-envelope"></i> makiar100k@gmail.com</p>
            <p><i class="fas fa-phone-alt"></i> 935356530</p>
            <div class="redes-sociales">
                <i class="fab fa-facebook-square"></i>
                <i class="fab fa-twitter-square"></i>
                <i class="fab fa-instagram"></i>
            </div>
        </div>

        <form class="formulario">
            <div class="input-formulario">
                <label for="nombre">Nombre</label>
                <input type="text" placeholder="luis" id="nombre">
            </div>
            <div class="input-formulario">
                <label for="apellidos">Apellido</label>
                <input type="text" placeholder="Ramirez" id="apellidos">
            </div>
            <div class="input-formulario">
                <label for="correo">Correo</label>
                <input type="email" placeholder="ejemplo@gmail.com" id="correo">
            </div>
            <div class="input-formulario">
                <label for="telefono">Teléfono</label>
                <input type="tel" placeholder="935356530" id="telefono">
            </div>
            <div class="input-formulario">
                <label for="mensaje">Mensaje</label>
                <textarea></textarea>
            </div>
            <div class="btn-formulario">
                <input type="submit" class="btn btn-verde" value="Enviar">
            </div>
        </form>
    </div>
    
    <div class="pie-pagina">
        <div class="contenedor-piepagina contenedor">
            <div class="info">
                <h3>Dirección</h3>
                <p>JR. matate buscando S/N</p>
            </div>
            
            <div class="info">
                <h3>Horarios</h3>
                <p>Lunes - Domingo 7am - 9pm</p>
                <div class="redes-sociales redes-pie">
                    <i class="fab fa-facebook-square"></i>
                    <i class="fab fa-twitter-square"></i>
                    <i class="fab fa-instagram"></i>
                </div>
            </div>
            
        </div>
    </div>
    
    <footer class="footer">
        <p>Todos los derechos reservados &copy; 2024 ,desarrollado por AlexGSR</p>
    </footer>
    <script src="js/app.js"></script>
</body>

</html>
