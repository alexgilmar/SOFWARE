<?php
// Configuración de la base de datos
$host = 'localhost';
$username = 'tu_usuario';
$password = 'tu_contraseña';
$database = 'tu_base_de_datos';
$backupDir = __DIR__ . '/backups';
$backupFile = $backupDir . '/db_backup_' . date('Y-m-d_H-i-s') . '.sql';

// Crear directorio de backups si no existe
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Crear backup de la base de datos
$command = "mysqldump --user={$username} --password={$password} --host={$host} {$database} > {$backupFile}";
exec($command, $output, $return_var);
if ($return_var == 0) {
    echo 'Backup de base de datos creado exitosamente: ' . $backupFile . '<br>';
} else {
    echo 'Error al crear el backup de la base de datos.<br>';
}

// Crear backup de los archivos del sitio
$zipFile = $backupDir . '/backup_files_' . date('Y-m-d_H-i-s') . '.zip';
function zipData($source, $destination) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));

    if (is_dir($source) === true) {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

        foreach ($files as $file) {
            $file = str_replace('\\', '/', $file);

            if (in_array(substr($file, strrpos($file, '/') + 1), array('.', '..')))
                continue;

            $file = realpath($file);
            if (is_dir($file) === true) {
                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            } elseif (is_file($file) === true) {
                $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
            }
        }
    } elseif (is_file($source) === true) {
        $zip->addFromString(basename($source), file_get_contents($source));
    }

    return $zip->close();
}

$source = __DIR__;
if (zipData($source, $zipFile)) {
    echo 'Backup de archivos creado exitosamente: ' . $zipFile;
} else {
    echo 'Error al crear el backup de archivos.';
}
?>
